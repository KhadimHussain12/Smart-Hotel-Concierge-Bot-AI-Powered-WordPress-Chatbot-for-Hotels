<?php
/**
 * Plugin Name: Smart Hotel Concierge Bot
 * Description: AI-powered hotel concierge chatbot with instant guest answers and client-side CSV/PDF export.
 * Version: 1.0.0
 * Author: KHADAM HUSSAIN SHAH
 */

if (!defined('ABSPATH')) exit;

function shcb_enqueue_assets() {
    wp_enqueue_style('shcb-style', plugins_url('assets/style.css', __FILE__));
    wp_enqueue_script('shcb-script', plugins_url('assets/script.js', __FILE__), [], null, true);
}
add_action('wp_enqueue_scripts', 'shcb_enqueue_assets');

function shcb_shortcode() {
    ob_start(); ?>
    <div class="shcb-card" id="shcb-root">
        <header>
            <h2>Smart Hotel Concierge</h2>
            <p>Every guest feels five‑star — even in a three‑star room.</p>
        </header>

        <div class="shcb-chat" id="shcb-chat"></div>

        <textarea id="shcb-input" placeholder="Ask about restaurants, tours, late checkout..."></textarea>

        <div class="shcb-actions">
            <button id="shcb-send">Ask Concierge</button>
            <button id="shcb-csv" class="muted">Export CSV</button>
            <button id="shcb-pdf" class="muted">Download PDF</button>
        </div>

        <small class="shcb-note">
            Disclaimer: Responses are AI-generated for educational use only. Always verify with hotel staff.
        </small>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('hotel_concierge_bot', 'shcb_shortcode');
