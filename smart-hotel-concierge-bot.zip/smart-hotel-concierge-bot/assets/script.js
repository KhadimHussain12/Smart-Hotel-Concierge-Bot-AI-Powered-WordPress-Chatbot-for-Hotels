(function(){
  const chat = document.getElementById('shcb-chat');
  const input = document.getElementById('shcb-input');
  const send = document.getElementById('shcb-send');
  const csvBtn = document.getElementById('shcb-csv');
  const pdfBtn = document.getElementById('shcb-pdf');
  let logs = [];

  function addMsg(role, text){
    logs.push({role, text, time:new Date().toISOString()});
    const div = document.createElement('div');
    div.className = 'shcb-msg';
    div.innerHTML = '<b>'+(role==='guest'?'Guest':'Concierge')+':</b> '+text;
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
  }

  function demoReply(q){
    q=q.toLowerCase();
    if(q.includes('restaurant')) return "I recommend our rooftop restaurant or the local Italian bistro nearby.";
    if(q.includes('late')) return "Late checkout is available until 2 PM for premium guests.";
    if(q.includes('tour')) return "City tours and airport transfers are available at the front desk.";
    return "I’m here to help! Ask about dining, tours, or special packages.";
  }

  send.onclick = ()=>{
    const q = input.value.trim();
    if(!q) return;
    addMsg('guest', q);
    input.value='';
    setTimeout(()=> addMsg('ai', demoReply(q)), 500);
  };

  csvBtn.onclick = ()=>{
    let rows = ["Role,Message,Time"];
    logs.forEach(l=> rows.push(`${l.role},"${l.text.replace(/"/g,'""')}",${l.time}`));
    const blob = new Blob([rows.join("\n")],{type:"text/csv"});
    const a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download="hotel-concierge-report.csv";
    a.click();
  };

  pdfBtn.onclick = ()=>{
    let html="<h2>Hotel Concierge Chat Report</h2><ul>";
    logs.forEach(l=> html+=`<li><b>${l.role}:</b> ${l.text}</li>`);
    html+="</ul>";
    const w=window.open("");
    w.document.write(html);
    w.print();
  };
})();
